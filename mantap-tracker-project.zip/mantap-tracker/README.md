# Mantap Tracker — Android WebView APK + Online Dashboard

A consent-based activity logging demo. Users manually enter their name, email, and phone number, review a consent notice, and submit. The server records the submitted fields, server-side timestamp, and activity type. No contacts, Gmail account, call logs, SMS, or hidden device data are accessed.

## Project layout
- `android/`: Android Studio project (Kotlin WebView wrapper)
- `server/`: Node.js + Express online backend and admin dashboard

## Important security notes
- The requested `mantap` / `123` credentials are demo defaults only. Change them before public use.
- Deploy only behind HTTPS. Do not expose the server over plain HTTP.
- Set a long random `SESSION_SECRET`.
- The demo uses a JSON file for records and Express's in-memory session store. For production, use a managed database and persistent session store.
- Collect personal data only with clear notice, consent, a retention policy, and appropriate safeguards under applicable privacy law.
- The APK does not contain an admin password. Admin authentication happens on the server.

## 1. Run the server locally
Install Node.js 20 or newer, then:

```bash
cd server
npm install
ADMIN_USERNAME=mantap ADMIN_PASSWORD=123 SESSION_SECRET="replace-with-a-long-random-secret" PORT=3000 npm start
```

Open `http://localhost:3000` in a browser. The public user form is `/`; the admin dashboard is `/admin`.

For online use, deploy the `server` folder to a Node.js host that supports persistent storage, configure the environment variables, attach persistent storage for `data/records.json`, and enable HTTPS. Use the deployed HTTPS base URL in the Android project.

## 2. Build the APK
1. Open the `android` folder in Android Studio.
2. In `android/app/build.gradle.kts`, replace `https://YOUR-HTTPS-SERVER.example` with your deployed HTTPS URL.
3. Sync Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your test phone.

The APK is a WebView client for the online form. It needs internet access to contact your server.

## 3. Admin login
- Username: `mantap`
- Password: `123`

These are deliberately weak demo credentials. Change them using environment variables before sharing the app.

## 4. API
- `POST /api/submit` — submits consented form data
- `POST /api/admin/login` — administrator login
- `POST /api/admin/logout` — logout
- `GET /api/admin/records` — admin-only records

## 5. Data handling
The app records only:
- user-provided name
- user-provided email
- user-provided phone number
- server timestamp
- activity type (`form_submitted`)

No data is transmitted until the user checks the consent box and taps Submit.
