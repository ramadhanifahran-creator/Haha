const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "mantap";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "123";
const SESSION_SECRET = process.env.SESSION_SECRET || "CHANGE-ME-TO-A-LONG-RANDOM-SECRET";
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "records.json");

if (SESSION_SECRET === "CHANGE-ME-TO-A-LONG-RANDOM-SECRET") {
  console.warn("WARNING: Set SESSION_SECRET to a long random value before deployment.");
}
if (ADMIN_PASSWORD === "123") {
  console.warn("WARNING: Admin password is the weak demo password. Change ADMIN_PASSWORD before public deployment.");
}

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]", "utf8");

function readRecords() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function writeRecords(records) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(records, null, 2), "utf8");
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use(session({
  name: "mantap_admin_session",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 4
  }
}));

const submitLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false });
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false });

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin === true) return next();
  return res.status(401).json({ error: "Admin login required." });
}

app.get("/", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.get("/admin", (_req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));

app.post("/api/submit", submitLimiter, (req, res) => {
  const { name, email, phone, consent } = req.body || {};
  if (consent !== true) return res.status(400).json({ error: "Persetujuan wajib diberikan." });
  if (typeof name !== "string" || name.trim().length < 1 || name.trim().length > 80)
    return res.status(400).json({ error: "Nama wajib diisi (maksimal 80 karakter)." });
  if (typeof email !== "string" || email.trim().length > 120 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()))
    return res.status(400).json({ error: "Email tidak valid." });
  if (typeof phone !== "string" || !/^[0-9+() .-]{7,24}$/.test(phone.trim()))
    return res.status(400).json({ error: "Nomor HP tidak valid." });

  const records = readRecords();
  const record = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name: name.trim(),
    email: email.trim(),
    phone: phone.trim(),
    timestamp: new Date().toISOString(),
    activity: "form_submitted",
    consent: true
  };
  records.unshift(record);
  writeRecords(records);
  res.status(201).json({ ok: true, message: "Data yang kamu setujui berhasil dikirim." });
});

app.post("/api/admin/login", loginLimiter, (req, res) => {
  const { username, password } = req.body || {};
  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD)
    return res.status(401).json({ error: "Username atau password salah." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Gagal membuat sesi login." });
    req.session.isAdmin = true;
    res.json({ ok: true });
  });
});

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("mantap_admin_session");
    res.json({ ok: true });
  });
});

app.get("/api/admin/records", requireAdmin, (_req, res) => {
  const records = readRecords();
  res.json({ total: records.length, records });
});

app.get("/health", (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`Mantap Tracker server listening on port ${PORT}`));
