plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.mantap.tracker"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.mantap.tracker"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // Replace with your deployed HTTPS server URL (no trailing slash).
        buildConfigField("String", "BASE_URL", "\"https://YOUR-HTTPS-SERVER.example\"")
    }

    buildFeatures { buildConfig = true }
}
